declare const verifyIdFrontApi: (transactionId: string, imageBase64: string) => Promise<any>;
export default verifyIdFrontApi;
//# sourceMappingURL=front.d.ts.map