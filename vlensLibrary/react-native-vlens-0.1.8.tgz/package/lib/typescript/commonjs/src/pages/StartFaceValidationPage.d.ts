type StartFaceValidationPageProps = {
    onNext: (error?: string) => void;
};
export default function StartFaceValidationPage({ onNext }: StartFaceValidationPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=StartFaceValidationPage.d.ts.map