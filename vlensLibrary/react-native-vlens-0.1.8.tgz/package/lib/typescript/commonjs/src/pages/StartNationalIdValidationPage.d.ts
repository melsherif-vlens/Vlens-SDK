type StartNationalIdValidationPageProps = {
    onNext: (error?: string) => void;
};
export default function StartNationalIdValidationPage({ onNext }: StartNationalIdValidationPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=StartNationalIdValidationPage.d.ts.map