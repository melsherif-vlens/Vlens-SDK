type NationalIdValidationPageProps = {
    onNext: (error?: string) => void;
    onPrev: () => void;
};
export default function NationalIdValidationPage({ onNext, onPrev }: NationalIdValidationPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NationalIdValidationPage.d.ts.map