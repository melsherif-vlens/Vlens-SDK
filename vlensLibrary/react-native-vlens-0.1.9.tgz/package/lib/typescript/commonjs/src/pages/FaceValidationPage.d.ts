type FaceValidationPageProps = {
    onNext: (error?: string) => void;
    onPrev: () => void;
};
export default function FaceValidationPage({ onNext, onPrev }: FaceValidationPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=FaceValidationPage.d.ts.map