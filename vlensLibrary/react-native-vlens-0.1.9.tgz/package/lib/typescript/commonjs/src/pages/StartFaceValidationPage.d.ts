type StartFaceValidationPageProps = {
    onNext: (error?: string) => void;
    onPrev: () => void;
};
export default function StartFaceValidationPage({ onNext, onPrev }: StartFaceValidationPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=StartFaceValidationPage.d.ts.map