declare const verifyIdBackApi: (transactionId: string, imageBase64: string) => Promise<{
    isVerificationProcessCompleted: any;
    isDigitalIdentityVerified: any;
}>;
export default verifyIdBackApi;
//# sourceMappingURL=back.d.ts.map