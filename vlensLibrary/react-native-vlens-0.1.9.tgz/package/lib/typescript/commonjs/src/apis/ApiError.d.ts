import type { ApiError } from '../types/SdkConfig';
export declare const handleApiError: (error: any) => Error;
export declare const defaultApiErrors: ApiError[];
export declare const getApiError: (errorCode: number, errorsData?: ApiError[]) => string;
//# sourceMappingURL=ApiError.d.ts.map