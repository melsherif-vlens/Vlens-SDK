declare const verifyIdFrontApi: (transactionId: string, imageBase64: string) => Promise<{
    isVerificationProcessCompleted: any;
    isDigitalIdentityVerified: any;
}>;
export default verifyIdFrontApi;
//# sourceMappingURL=front.d.ts.map