type NationalIdValidationErrorViewProps = {
    errorMsg: string;
    handleRetryScanning: () => void;
    handleExist: () => void;
};
export default function NationalIdValidationErrorView({ errorMsg, handleRetryScanning, handleExist }: NationalIdValidationErrorViewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NationalIdValidationErrorView.d.ts.map