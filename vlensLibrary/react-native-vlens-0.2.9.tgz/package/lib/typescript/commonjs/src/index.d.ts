import type { SdkConfig } from './types/SdkConfig';
type VLensViewProps = SdkConfig;
declare const VLensView: (props: VLensViewProps) => import("react/jsx-runtime").JSX.Element;
export default VLensView;
//# sourceMappingURL=index.d.ts.map