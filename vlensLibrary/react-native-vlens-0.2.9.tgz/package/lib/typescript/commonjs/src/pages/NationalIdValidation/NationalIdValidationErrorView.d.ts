type NationalIdValidationErrorViewProps = {
    errorMsg: string;
    isAllowedToRetry: boolean;
    handleRetryScanning: () => void;
    handleExist: () => void;
};
export default function NationalIdValidationErrorView({ errorMsg, isAllowedToRetry, handleRetryScanning, handleExist }: NationalIdValidationErrorViewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NationalIdValidationErrorView.d.ts.map