export default function NationalIdValidationLoadingView(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=NationalIdValidationLoadingView.d.ts.map