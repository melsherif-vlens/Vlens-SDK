type NationalIdBackValidationCameraViewProps = {
    callback: (imageInBase64: string) => void;
};
export default function NationalIdBackValidationCameraView({ callback }: NationalIdBackValidationCameraViewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NationalIdBackValidationCameraView.d.ts.map