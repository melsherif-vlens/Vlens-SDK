type StartNationalIdValidationPageProps = {
    onNext: (errorCode?: string, error?: string) => void;
    onPrev: () => void;
};
export default function StartNationalIdValidationPage({ onNext, onPrev }: StartNationalIdValidationPageProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=StartNationalIdValidationPage.d.ts.map