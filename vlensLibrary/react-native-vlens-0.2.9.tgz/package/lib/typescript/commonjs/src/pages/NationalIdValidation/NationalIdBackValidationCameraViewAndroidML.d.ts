type NationalIdBackValidationCameraViewAndroidProps = {
    callback: (imageInBase64: string) => void;
};
export default function NationalIdBackValidationCameraViewAndroid({ callback }: NationalIdBackValidationCameraViewAndroidProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NationalIdBackValidationCameraViewAndroidML.d.ts.map