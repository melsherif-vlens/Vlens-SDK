type Props = {
    step: "front" | "flip" | "back";
};
export default function CameraOverlayView({ step }: Props): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CameraOverlayView.d.ts.map