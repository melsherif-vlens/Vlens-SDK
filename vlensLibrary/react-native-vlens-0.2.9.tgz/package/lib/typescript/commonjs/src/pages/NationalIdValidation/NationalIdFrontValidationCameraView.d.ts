type NationalIdFrontValidationCameraViewProps = {
    callback: (imageInBase64: string) => void;
};
export default function NationalIdFrontValidationCameraView({ callback }: NationalIdFrontValidationCameraViewProps): import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=NationalIdFrontValidationCameraView.d.ts.map