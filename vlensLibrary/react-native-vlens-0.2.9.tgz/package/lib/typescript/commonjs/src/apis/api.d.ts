declare const API: import("axios").AxiosInstance;
export default API;
//# sourceMappingURL=api.d.ts.map