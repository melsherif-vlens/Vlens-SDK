declare const verifyFaceApi: (transactionId: string, face1: string, face2: string, face3: string) => Promise<{
    isVerificationProcessCompleted: any;
    isDigitalIdentityVerified: any;
    isMatched: any;
}>;
export default verifyFaceApi;
//# sourceMappingURL=face.d.ts.map