declare const verifyIdBackApi: (transactionId: string, imageBase64: string) => Promise<any>;
export default verifyIdBackApi;
//# sourceMappingURL=back.d.ts.map