declare const verifyIdFrontApi: (transactionId: string, imageBase64: string) => Promise<{
    isVerificationProcessCompleted: boolean;
    isDigitalIdentityVerified: boolean;
}>;
export default verifyIdFrontApi;
//# sourceMappingURL=front.d.ts.map