declare const compressBase64Image: (base64Image: string) => Promise<string>;
export default compressBase64Image;
//# sourceMappingURL=compressBase64Image.d.ts.map