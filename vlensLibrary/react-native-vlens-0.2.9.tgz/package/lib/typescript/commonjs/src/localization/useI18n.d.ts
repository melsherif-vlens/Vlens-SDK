type UseI18nReturn = {
    t: (key: string, values?: Record<string, string | number | null | undefined>) => string;
    locale: string;
    isArabic: boolean;
    isRTL: boolean;
    direction: 'ltr' | 'rtl';
};
export declare function useI18n(): UseI18nReturn;
export {};
//# sourceMappingURL=useI18n.d.ts.map