import type { SdkConfig } from './types/SdkConfig';
export declare const sdkConfig: SdkConfig;
//# sourceMappingURL=appConfig.d.ts.map